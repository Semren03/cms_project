﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace listBoxComboExample1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("ali");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(textBox1.Text!="")
            listBox1.Items.Add(textBox1.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Insert(0,"1212");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int loc;
            loc =Convert.ToInt32( textBox2.Text);
            if (loc >= 0 && loc <= listBox1.Items.Count)
                listBox1.Items.Insert(loc,
                    textBox1.Text);
            else
                MessageBox.Show("Invalid index");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
                listBox1.Items.Insert(listBox1.SelectedIndex, textBox1.Text);
            else
                MessageBox.Show("Please select and item from the list to insert before");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            listBox1.Items.Remove(textBox1.Text);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int loc;
            loc = Convert.ToInt32(textBox2.Text);
            if (loc >= 0 && loc <= listBox1.Items.Count-1)
                listBox1.Items.RemoveAt(loc);
            else
                MessageBox.Show("Invalid index");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            // listBox1.Items.Remove(listBox1.SelectedItem);
            if (listBox1.SelectedIndex >= 0)
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            else
                MessageBox.Show("Please select an item to be removed");

        }

        private void button9_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)//validation
            {
                int loc = listBox1.SelectedIndex;
                string val = textBox1.Text;
                listBox1.Items[loc] = val;
            }
            else
                MessageBox.Show("Please select an item to be updated");
            //listBox1.Items[listBox1.SelectedIndex]= textBox1.Text;
            //listBox1.Items[0] = "hello";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
           // for (int i = 0; i <= listBox1.Items.Count - 1; i++)//not correct
           for(int i=listBox1.Items.Count-1;i>=0;i--)
                if (listBox1.Items[i].ToString()==textBox1.Text)
                listBox1.Items.RemoveAt(i);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            int j = listBox1.Items.Count - 1;
            object temp;
            for(int i=0;i<=j;i++)
            {
                temp = listBox1.Items[i];
                listBox1.Items[i] = listBox1.Items[j];
                listBox1.Items[j] = temp;
                j--;

            }
        }
        private void button13_Click(object sender, EventArgs e)
        {
            
            List<object> lst = new List<object>();
            for(int i=0;i<=listBox1.Items.Count-1; i++)//copy all items to lst
                lst.Add(listBox1.Items[i]);
            listBox1.Items.Clear();//empty listBox1
            for(int i=lst.Count-1;i>=0;i--)//return the items of lst in revers order
                listBox1.Items.Add(lst[i]);

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if(listBox1.SelectedIndex>=0)
            comboBox1.Items.Add(listBox1.SelectedItem);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                comboBox1.Items.Add(listBox1.SelectedItem);
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <= listBox1.Items.Count - 1; i++)
                comboBox1.Items.Add(listBox1.Items[i]);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <= listBox1.Items.Count - 1; i++)
                comboBox1.Items.Add(listBox1.Items[i]);
            listBox1.Items.Clear();

        }

        private void button18_Click(object sender, EventArgs e)
        {
            object temp;
            if (listBox1.SelectedIndex >= 0 && comboBox1.SelectedIndex >= 0)
            {
                temp = listBox1.SelectedItem;
                listBox1.Items[listBox1.SelectedIndex] = comboBox1.SelectedItem;
                comboBox1.Items[comboBox1.SelectedIndex] = temp;
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            List<object> temp= new List<object>();
            //copy all items from listBox1 to temp
            for(int i = 0;i<= listBox1.Items.Count -1;i++)
                temp.Add(listBox1.Items[i]);
            //clear listBox1
            listBox1.Items.Clear();
            for(int i= 0;i<= comboBox1.Items.Count-1;i++)
                listBox1.Items.Add(comboBox1.Items[i]);
            //clear comboBox1
            comboBox1.Items.Clear();
            //copy all items from temp to comboBox
            for (int i = 0; i <= temp.Count - 1; i++)
                comboBox1.Items.Add(temp[i]);
        }
    }
}
